CREATE TABLE `album_embeddings` (
	`id` integer PRIMARY KEY AUTOINCREMENT,
	`beets_id` integer NOT NULL,
	`embedding` blob NOT NULL,
	`model` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `albums` (
	`id` integer PRIMARY KEY AUTOINCREMENT,
	`beets_id` integer NOT NULL UNIQUE,
	`artist` text NOT NULL,
	`title` text NOT NULL,
	`art_path` text
);
--> statement-breakpoint
CREATE TABLE `song_embeddings` (
	`id` integer PRIMARY KEY AUTOINCREMENT,
	`beets_id` integer NOT NULL,
	`embedding` blob NOT NULL,
	`model` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `songs` (
	`id` integer PRIMARY KEY AUTOINCREMENT,
	`beets_id` integer NOT NULL UNIQUE,
	`beets_album_id` integer,
	`title` text NOT NULL,
	`path` text NOT NULL,
	CONSTRAINT `fk_songs_beets_album_id_albums_beets_id_fk` FOREIGN KEY (`beets_album_id`) REFERENCES `albums`(`beets_id`)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `album_embeddings_beets_id_model` ON `album_embeddings` (`beets_id`,`model`);--> statement-breakpoint
CREATE UNIQUE INDEX `song_embeddings_beets_id_model` ON `song_embeddings` (`beets_id`,`model`);