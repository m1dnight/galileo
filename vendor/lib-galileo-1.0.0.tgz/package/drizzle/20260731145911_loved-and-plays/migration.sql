CREATE TABLE `loved_albums` (
	`id` integer PRIMARY KEY AUTOINCREMENT,
	`beets_id` integer NOT NULL UNIQUE,
	`loved_at` integer NOT NULL,
	CONSTRAINT `fk_loved_albums_beets_id_albums_beets_id_fk` FOREIGN KEY (`beets_id`) REFERENCES `albums`(`beets_id`)
);
--> statement-breakpoint
CREATE TABLE `plays` (
	`id` integer PRIMARY KEY AUTOINCREMENT,
	`beets_id` integer NOT NULL,
	`played_at` integer NOT NULL,
	CONSTRAINT `fk_plays_beets_id_albums_beets_id_fk` FOREIGN KEY (`beets_id`) REFERENCES `albums`(`beets_id`)
);
--> statement-breakpoint
CREATE INDEX `plays_beets_id` ON `plays` (`beets_id`);