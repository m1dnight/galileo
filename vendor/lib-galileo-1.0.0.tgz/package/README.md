# Lib Galileo

This is a library for analyzing music from a Beets collection.

It assumes you have a music collection managed by Beets, and needs access to
your Beets database.

## Functionality

 - Analyze all your songs with CLAP, PANN, and MERT models to create embeddings
   for each individual song and album.
 - Find similar albums based on the computed embeddings.


## Using it

I have built a small music player that relies on this library to rediscover my
music collection. There is a test script under `examples/import.ts` to try your
hand at analyzing your own library.

```bash
# Absolute path to your Beets library database.
export BEETS_LIBRARY=/path/to/beets/library.db
# The path where your Beets music files are actually located.
export FILE_PREFIX=/path/to/your/beets/library
# Analyze using GPU or CPU
export DEVICE=gpu
# Path where to write your sidecar database (the database built by this library)
export SIDECAR=sidecar.db
# Path to the Mert model
export MERT_MODEL=/path/to/mert/model.onxx
# Path to the Pann model
export PANN_MODEL=/path/to/pann/model.onxx

# Amount of shards that will analyze your music
export SHARDS=1
export SHARD=1
npm run dev -- analyze
npm run dev -- embedalbums
npm run dev -- stats
npm run dev -- importbeets
```